# Youtube Video Blocker

It's yet another video blocker for Firefox but a working one! It is listed at :

https://addons.mozilla.org/en-US/firefox/addon/youtube-video-blocker/

Lemonrice's video blocker is not working for Firefox anymore. It has not much functionality as Lemonrice's but it is ok. You can define keywords with regex.

# Examples

I want to block : Adnan Oktar
    
Should add this : Adnan Oktar

---

I want to block : Jahrein

Should add this : jahre[iİ]n  // No need to put ignore case flag. Extension has already.


