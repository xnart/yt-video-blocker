[![codebeat badge](https://codebeat.co/badges/e6c138c9-a519-43c9-8cfc-44688f1f398f)](https://codebeat.co/projects/github-com-xnart-yt-video-blocker-master)

# Youtube Video Blocker 

It's yet another video blocker for Firefox but a working one! It is listed at :

https://addons.mozilla.org/en-US/firefox/addon/youtube-video-blocker/

Lemonrice's video blocker is not working for Firefox anymore. It has not much functionality as Lemonrice's but it is ok. You can define keywords with regex.

# Examples

To block : Adnan Oktar
    
To add : Adnan Oktar

---

To block : Jahrein

To add : jahrein  // No need to put ignore case flag. Extension has already.


---

Also, feel free to use regular expressions.
